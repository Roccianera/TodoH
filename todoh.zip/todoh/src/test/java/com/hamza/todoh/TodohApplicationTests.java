package com.hamza.todoh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodohApplicationTests {

	@Test
	void contextLoads() {
	}

}
