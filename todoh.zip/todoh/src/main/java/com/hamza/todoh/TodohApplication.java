package com.hamza.todoh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodohApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodohApplication.class, args);
	}

}
